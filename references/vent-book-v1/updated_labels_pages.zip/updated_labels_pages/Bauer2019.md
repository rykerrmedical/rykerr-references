---
permalink: /Bauer2019.html
layout: default
---

<div class="ref-controls">
  <a href="https://www.flightbridgeed.com/index.php/the-flightbridgeed-podcast/2-flightbridgeed-podcast/23-pressure-control-prvc-modes-of-ventilation" target="_blank" class="ref-link">Link to Original Website</a>
  <a href="https://web.archive.org/web/https://www.flightbridgeed.com/index.php/the-flightbridgeed-podcast/2-flightbridgeed-podcast/23-pressure-control-prvc-modes-of-ventilation" target="_blank" class="ref-link">Link to Page on Archive.org</a>
  <button onclick="loadArchive()" class="ref-button">View Archive Page in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://www.flightbridgeed.com/index.php/the-flightbridgeed-podcast/2-flightbridgeed-podcast/23-pressure-control-prvc-modes-of-ventilation"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://www.flightbridgeed.com/index.php/the-flightbridgeed-podcast/2-flightbridgeed-podcast/23-pressure-control-prvc-modes-of-ventilation';
}
</script>
