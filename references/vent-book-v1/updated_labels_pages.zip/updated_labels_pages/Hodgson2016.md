---
permalink: /Hodgson2016.html
layout: default
---

<div class="ref-controls">
  <a href="https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD006667.pub3/full" target="_blank" class="ref-link">Link to Original Website</a>
  <a href="https://web.archive.org/web/https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD006667.pub3/full" target="_blank" class="ref-link">Link to Page on Archive.org</a>
  <button onclick="loadArchive()" class="ref-button">View Archive Page in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD006667.pub3/full"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD006667.pub3/full';
}
</script>
