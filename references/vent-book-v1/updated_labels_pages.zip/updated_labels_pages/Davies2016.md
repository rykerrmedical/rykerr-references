---
permalink: /Davies2016.html
layout: default
---

<div class="ref-controls">
  <a href="http://rc.rcjournal.com/content/61/6/774" target="_blank" class="ref-link">Link to Original Website</a>
  <a href="https://web.archive.org/web/http://rc.rcjournal.com/content/61/6/774" target="_blank" class="ref-link">Link to Page on Archive.org</a>
  <button onclick="loadArchive()" class="ref-button">View Archive Page in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="http://rc.rcjournal.com/content/61/6/774"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/http://rc.rcjournal.com/content/61/6/774';
}
</script>
