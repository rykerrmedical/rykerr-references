---
permalink: /Loderserto2018Part4.html
layout: default
---

<div class="ref-controls">
  <a href="https://rebelem.com/simplifying-mechanical-ventilation-part-4-obstructive-physiology/" target="_blank" class="ref-link">Link to Original Website</a>
  <a href="https://web.archive.org/web/https://rebelem.com/simplifying-mechanical-ventilation-part-4-obstructive-physiology/" target="_blank" class="ref-link">Link to Page on Archive.org</a>
  <button onclick="loadArchive()" class="ref-button">View Archive Page in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://rebelem.com/simplifying-mechanical-ventilation-part-4-obstructive-physiology/"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://rebelem.com/simplifying-mechanical-ventilation-part-4-obstructive-physiology/';
}
</script>
