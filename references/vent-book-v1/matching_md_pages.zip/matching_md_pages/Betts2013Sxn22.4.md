---
permalink: /Betts2013Sxn22.4.html
layout: default
---

<div class="ref-controls">
  <a href="https://openstax.org/books/anatomy-and-physiology/pages/22-4-gas-exchange" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://openstax.org/books/anatomy-and-physiology/pages/22-4-gas-exchange" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://openstax.org/books/anatomy-and-physiology/pages/22-4-gas-exchange"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://openstax.org/books/anatomy-and-physiology/pages/22-4-gas-exchange';
}
</script>
