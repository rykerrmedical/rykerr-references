---
permalink: /Weingart2011.html
layout: default
---

<div class="ref-controls">
  <a href="https://emcrit.org/emcrit/origins-of-the-dope-mnemonic/" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://emcrit.org/emcrit/origins-of-the-dope-mnemonic/" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://emcrit.org/emcrit/origins-of-the-dope-mnemonic/"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://emcrit.org/emcrit/origins-of-the-dope-mnemonic/';
}
</script>
