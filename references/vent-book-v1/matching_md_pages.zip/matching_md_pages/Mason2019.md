---
permalink: /Mason2019.html
layout: default
---

<div class="ref-controls">
  <a href="https://www.youtube.com/playlist?list=PLKbsytZxJw7_ObYvaAtmrzbFDUIzJvdU2" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://www.youtube.com/playlist?list=PLKbsytZxJw7_ObYvaAtmrzbFDUIzJvdU2" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://www.youtube.com/playlist?list=PLKbsytZxJw7_ObYvaAtmrzbFDUIzJvdU2"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://www.youtube.com/playlist?list=PLKbsytZxJw7_ObYvaAtmrzbFDUIzJvdU2';
}
</script>
