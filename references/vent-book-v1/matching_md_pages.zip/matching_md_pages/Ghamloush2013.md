---
permalink: /Ghamloush2013.html
layout: default
---

<div class="ref-controls">
  <a href="http://rc.rcjournal.com/content/58/11/1992" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/http://rc.rcjournal.com/content/58/11/1992" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="http://rc.rcjournal.com/content/58/11/1992"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/http://rc.rcjournal.com/content/58/11/1992';
}
</script>
