---
permalink: /Yartsev2019PPV&CV.html
layout: default
---

<div class="ref-controls">
  <a href="https://derangedphysiology.com/main/cicm-primary-exam/required-reading/respiratory-system/Chapter%20523/effects-positive-pressure-ventilation-cardiovascular-physiology" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://derangedphysiology.com/main/cicm-primary-exam/required-reading/respiratory-system/Chapter%2520523/effects-positive-pressure-ventilation-cardiovascular-physiology" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://derangedphysiology.com/main/cicm-primary-exam/required-reading/respiratory-system/Chapter%20523/effects-positive-pressure-ventilation-cardiovascular-physiology"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://derangedphysiology.com/main/cicm-primary-exam/required-reading/respiratory-system/Chapter%2520523/effects-positive-pressure-ventilation-cardiovascular-physiology';
}
</script>
