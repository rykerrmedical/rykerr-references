---
permalink: /Thoracic.orgVideos.html
layout: default
---

<div class="ref-controls">
  <a href="https://www.thoracic.org/professionals/clinical-resources/video-lecture-series/mechanical-ventilation/index.php" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://www.thoracic.org/professionals/clinical-resources/video-lecture-series/mechanical-ventilation/index.php" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://www.thoracic.org/professionals/clinical-resources/video-lecture-series/mechanical-ventilation/index.php"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://www.thoracic.org/professionals/clinical-resources/video-lecture-series/mechanical-ventilation/index.php';
}
</script>
