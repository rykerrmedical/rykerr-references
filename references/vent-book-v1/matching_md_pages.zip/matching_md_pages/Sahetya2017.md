---
permalink: /Sahetya2017.html
layout: default
---

<div class="ref-controls">
  <a href="https://www.atsjournals.org/doi/full/10.1164/rccm.201708-1629CI" target="_blank" class="ref-link">Original Link</a>
  <a href="https://web.archive.org/web/https://www.atsjournals.org/doi/full/10.1164/rccm.201708-1629CI" target="_blank" class="ref-link">Archive Link</a>
  <button onclick="loadArchive()" class="ref-button">View Archive in Frame</button>
</div>

<div class="ref-frame-container">
  <iframe id="ref-frame" src="https://www.atsjournals.org/doi/full/10.1164/rccm.201708-1629CI"></iframe>
</div>

<script>
function loadArchive() {
  document.getElementById('ref-frame').src = 'https://web.archive.org/web/https://www.atsjournals.org/doi/full/10.1164/rccm.201708-1629CI';
}
</script>
